<?php

/**
 * For more information on how to create PHPUnit tests
 * for your extension, visit the documentation page:
 * https://www.mediawiki.org/wiki/Manual:PHP_unit_testing/Writing_unit_tests
 */
