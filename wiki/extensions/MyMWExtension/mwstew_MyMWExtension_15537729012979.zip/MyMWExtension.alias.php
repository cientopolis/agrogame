<?php
/**
 * Aliases for special pages in the MyMWExtension extension.
 */
// @codingStandardsIgnoreFile

$specialPageAliases = array();

/** English (English) */
$specialPageAliases['en'] = array(
	'myMWExtension' => array( 'myMWExtension' ),
);
