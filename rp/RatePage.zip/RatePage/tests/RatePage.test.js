( function () {
	QUnit.module( 'ext.ratePage' );

	/**
	 * Write your QUnit tests here. For more information on
	 * how to write proper JavaScript QUnit tests for
	 * MediaWiki extension development, please read
	 * the manual:
	 * https://www.mediawiki.org/wiki/Manual:JavaScript_unit_testing#Write_a_unit_test
	 */

} )();
